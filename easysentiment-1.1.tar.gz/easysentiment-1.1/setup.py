from setuptools import setup

setup(
	name='easysentiment',
	version= '1.1',
	scripts= ['scraper_and_analysis.py','scraper.py','sentiment_analysis.py']
)